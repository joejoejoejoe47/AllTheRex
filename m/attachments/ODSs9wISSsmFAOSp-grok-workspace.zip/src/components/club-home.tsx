import { useEffect, useState, type FormEvent } from "react";
import { Navigate, useNavigate } from "@tanstack/react-router";
import { Timer, Wind, X } from "lucide-react";
import { ClubSignOut } from "@/components/club-sign-out";
import { ThemeToggle } from "@/components/theme";
import { CheckTile, PieceMark } from "@/components/chess/marks";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import {
  cancelChallenge,
  claimUsername,
  getHomeState,
  joinQueue,
  leaveQueue,
  respondChallenge,
  sendChallenge,
  startBotGame,
  type HomeState,
} from "@/lib/server/mores";
import { BOT_USERNAME, USERNAME_RE, type GameMode } from "@/lib/mores-constants";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { SplashSkeleton } from "@/components/auth-screen";

type Flow =
  | { kind: "idle" }
  | { kind: "pick-mode"; intent: "random" | "challenge" | "bot" }
  | { kind: "ask-name"; mode: GameMode }
  | { kind: "searching"; mode: GameMode }
  | { kind: "waiting"; mode: GameMode; username: string; challengeId?: string };

export function ClubHome() {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [home, setHome] = useState<HomeState | null>(null);
  const [flow, setFlow] = useState<Flow>({ kind: "idle" });
  const [claim, setClaim] = useState("");
  const [target, setTarget] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    const tick = async () => {
      try {
        const next = await getHomeState();
        if (!live) return;
        setHome(next);
        setLoadError(null);
        if (next.activeGameId) {
          void navigate({ to: "/play/$gameId", params: { gameId: next.activeGameId } });
        }
      } catch (e) {
        if (live) setLoadError(e instanceof Error ? e.message : "Could not load the club.");
      }
    };
    void tick();
    const id = window.setInterval(() => void tick(), 1200);
    return () => {
      live = false;
      window.clearInterval(id);
    };
  }, [navigate]);

  if (isPending || !user) return <SplashSkeleton />;
  if (!home) {
    return (
      <main className="relative mx-auto flex min-h-dvh max-w-5xl flex-col px-5 py-8">
        <div className="check-wash pointer-events-none absolute inset-0" />
        <SplashSkeleton />
        {loadError ? <p className="relative mt-4 text-sm text-danger">{loadError}</p> : null}
      </main>
    );
  }

  if (home.activeGameId) {
    return <Navigate to="/play/$gameId" params={{ gameId: home.activeGameId }} />;
  }

  async function onClaim(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!USERNAME_RE.test(claim.trim())) {
      setError("Club names are 3–20 letters, numbers, or underscores.");
      return;
    }
    setBusy(true);
    try {
      await claimUsername({ data: { username: claim.trim() } });
      setHome(await getHomeState());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not claim that name.");
    } finally {
      setBusy(false);
    }
  }

  async function chooseMode(mode: GameMode) {
    if (flow.kind !== "pick-mode") return;
    setError(null);
    if (flow.intent === "challenge") {
      setFlow({ kind: "ask-name", mode });
      return;
    }
    setBusy(true);
    try {
      if (flow.intent === "bot") {
        const { gameId } = await startBotGame({ data: { mode } });
        await navigate({ to: "/play/$gameId", params: { gameId } });
        return;
      }
      const { gameId } = await joinQueue({ data: { mode } });
      if (gameId) {
        await navigate({ to: "/play/$gameId", params: { gameId } });
        return;
      }
      setFlow({ kind: "searching", mode });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not start a match.");
    } finally {
      setBusy(false);
    }
  }

  async function submitChallenge(e: FormEvent) {
    e.preventDefault();
    if (flow.kind !== "ask-name") return;
    setError(null);
    const name = target.trim();
    if (!USERNAME_RE.test(name)) {
      setError("Enter a club name (3–20 letters, numbers, or underscores).");
      return;
    }
    setBusy(true);
    try {
      const res = await sendChallenge({ data: { username: name, mode: flow.mode } });
      if (!res.ok) {
        setError(res.error);
        return;
      }
      if ("gameId" in res && res.gameId) {
        await navigate({ to: "/play/$gameId", params: { gameId: res.gameId } });
        return;
      }
      setFlow({ kind: "waiting", mode: flow.mode, username: name, challengeId: res.challengeId });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not send that challenge.");
    } finally {
      setBusy(false);
    }
  }

  if (!home.profile) {
    return (
      <main className="relative mx-auto flex min-h-dvh max-w-lg flex-col justify-center px-5 py-10">
        <div className="check-wash pointer-events-none absolute inset-0" />
        <header className="relative mb-10 flex items-center justify-between gap-3">
          <Wordmark />
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <ClubSignOut />
          </div>
        </header>
        <p className="relative text-xs uppercase tracking-[0.2em] text-mist">Claim your seat</p>
        <h1 className="relative mt-3 font-display text-4xl text-ivory">Choose a club name</h1>
        <p className="relative mt-3 text-sm text-mist">
          This is how other players challenge you across the board. Sign back in with it anytime.
        </p>
        <form className="relative mt-8 space-y-4" onSubmit={onClaim}>
          <div className="space-y-2">
            <Label htmlFor="claim">Club name</Label>
            <Input
              id="claim"
              value={claim}
              autoFocus
              onChange={(e) => setClaim(e.target.value)}
              placeholder="e.g. IvoryRook"
            />
          </div>
          {error ? <p className="text-sm text-danger">{error}</p> : null}
          <Button type="submit" variant="solid" className="w-full" disabled={busy}>
            {busy ? "Saving…" : "Take a seat"}
          </Button>
        </form>
      </main>
    );
  }

  return (
    <main className="relative mx-auto min-h-dvh w-full max-w-6xl px-5 py-6 sm:px-8">
      <div className="check-wash pointer-events-none absolute inset-0" />
      <header className="relative flex flex-wrap items-center justify-between gap-4">
        <Wordmark />
        <div className="flex items-center gap-3">
          <div className="rounded-md border border-line bg-panel px-3 py-2 text-right">
            <p className="text-xs uppercase tracking-[0.16em] text-mist">Rating</p>
            <p className="font-mono text-lg tabular-nums text-ivory">{home.profile.score}</p>
          </div>
          <ThemeToggle />
          <ClubSignOut />
        </div>
      </header>

      <section className="relative mt-10">
        <p className="text-xs uppercase tracking-[0.2em] text-mist">The clubhouse</p>
        <h1 className="mt-2 max-w-2xl font-display text-4xl text-ivory">White or black. Your move.</h1>
        <p className="mt-3 max-w-xl text-sm text-mist">
          Pair into a rated board near your score, or send a named challenge. Timed seats give each
          player one minute on the clock — it only runs on your turn, and it does not reset. Checkmate
          is worth eight rating points.
        </p>
      </section>

      <section className="relative mt-8 grid gap-4 md:grid-cols-2">
        <button
          type="button"
          onClick={() => setFlow({ kind: "pick-mode", intent: "random" })}
          className="felt-inset rounded-xl border border-line p-6 text-left transition-[border-color] duration-200 hover:border-line-strong"
        >
          <div className="flex items-center gap-3">
            <CheckTile />
            <PieceMark kind="n" className="size-7 text-cream" />
          </div>
          <h2 className="mt-4 font-display text-2xl text-ivory">Random pull-up</h2>
          <p className="mt-2 text-sm text-mist">
            Sit across from a player near your rating. Colors are drawn at the board. Quiet lounge?
            MoresBot holds the other chair.
          </p>
        </button>
        <button
          type="button"
          onClick={() => setFlow({ kind: "pick-mode", intent: "challenge" })}
          className="felt-inset rounded-xl border border-line p-6 text-left transition-[border-color] duration-200 hover:border-line-strong"
        >
          <div className="flex items-center gap-3">
            <CheckTile />
            <PieceMark kind="k" className="size-7 text-cream" />
          </div>
          <h2 className="mt-4 font-display text-2xl text-ivory">Intended pull-up</h2>
          <p className="mt-2 text-sm text-mist">
            Name a club player. They see you want to battle over the board, and a yes seats you both at
            once.
          </p>
        </button>
      </section>
      <button
        type="button"
        className="relative mt-3 inline-flex items-center gap-2 text-sm text-mist underline-offset-4 hover:text-ivory hover:underline"
        onClick={() => setFlow({ kind: "pick-mode", intent: "bot" })}
      >
        <PieceMark kind="p" className="size-4 text-cream" />
        Warm up against {BOT_USERNAME}
      </button>

      <section className="relative mt-10 grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
        <Card className="min-h-48">
          <div className="flex items-center gap-2">
            <PieceMark kind="q" className="size-5 text-cream" />
            <h2 className="font-display text-2xl">Challenges</h2>
          </div>
          <p className="mt-1 text-sm text-mist">Slips land here the moment someone names you.</p>
          <div className="mt-5 space-y-3">
            {home.inbox.length === 0 ? (
              <p className="text-sm text-mist">No one is waiting on you right now.</p>
            ) : (
              home.inbox.map((c) => (
                <div
                  key={c.id}
                  className="flex flex-col gap-3 rounded-md border border-line bg-ink-soft p-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <p className="text-sm text-ivory">
                    <span className="font-medium">{c.fromUsername}</span> wants to battle you in chess{" "}
                    {c.mode}.
                  </p>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="solid"
                      onClick={async () => {
                        const res = await respondChallenge({ data: { id: c.id, accept: true } });
                        if (res.ok && res.gameId) {
                          await navigate({ to: "/play/$gameId", params: { gameId: res.gameId } });
                        }
                      }}
                    >
                      Sit down
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => respondChallenge({ data: { id: c.id, accept: false } })}
                    >
                      Decline
                    </Button>
                  </div>
                </div>
              ))
            )}
            {home.outgoing
              .filter((c) => c.status === "pending")
              .map((c) => (
                <div
                  key={c.id}
                  className="flex items-center justify-between gap-3 rounded-md border border-line p-4"
                >
                  <p className="text-sm text-mist">
                    Waiting on {c.toUsername} for a {c.mode} game.
                  </p>
                  <Button size="sm" variant="ghost" onClick={() => cancelChallenge({ data: { id: c.id } })}>
                    Cancel
                  </Button>
                </div>
              ))}
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <div className="flex items-center gap-2">
              <PieceMark kind="r" className="size-5 text-cream" />
              <h2 className="font-display text-2xl">At the boards</h2>
            </div>
            <div className="mt-4 space-y-2">
              {home.online.length === 0 ? (
                <p className="text-sm text-mist">
                  The other chairs are empty. Challenge {BOT_USERNAME} or wait.
                </p>
              ) : (
                home.online.map((p) => (
                  <button
                    key={p.username}
                    type="button"
                    className="flex w-full items-center justify-between rounded-md px-2 py-2 text-left hover:bg-panel-2"
                    onClick={() => {
                      setTarget(p.username);
                      setFlow({ kind: "ask-name", mode: "timed" });
                    }}
                  >
                    <span className="inline-flex items-center gap-2 text-sm text-ivory">
                      <PieceMark kind="p" className="size-4 text-mist" />
                      {p.username}
                    </span>
                    <span className="font-mono text-xs tabular-nums text-mist">{p.score}</span>
                  </button>
                ))
              )}
            </div>
          </Card>
          <Card>
            <div className="flex items-center gap-2">
              <PieceMark kind="b" className="size-5 text-cream" />
              <h2 className="font-display text-2xl">Standings</h2>
            </div>
            <ol className="mt-4 space-y-2">
              {home.leaders.map((p, i) => (
                <li key={p.username} className="flex items-center justify-between text-sm">
                  <span className="text-mist">
                    <span className="mr-2 font-mono tabular-nums text-cream">{i + 1}</span>
                    {p.username}
                  </span>
                  <span className="font-mono tabular-nums text-ivory">{p.score}</span>
                </li>
              ))}
            </ol>
          </Card>
        </div>
      </section>

      <p className="file-rail relative mt-12 text-center text-xs">a b c d e f g h</p>

      {(flow.kind !== "idle" || home.queued) && (
        <div className="fixed inset-0 z-40 grid place-items-end bg-ink/70 p-4 sm:place-items-center">
          <div className="w-full max-w-md rounded-xl border border-line bg-panel p-6">
            <div className="flex items-start justify-between gap-3">
              <h2 className="font-display text-2xl text-ivory">
                {flow.kind === "pick-mode"
                  ? "How do you want to play?"
                  : flow.kind === "ask-name"
                    ? "Who sits across the board?"
                    : flow.kind === "searching" || home.queued
                      ? "Finding a board"
                      : "Challenge sent"}
              </h2>
              <button
                type="button"
                className="grid size-9 place-items-center rounded-md text-mist hover:bg-panel-2 hover:text-ivory"
                onClick={async () => {
                  if (home.queued) await leaveQueue();
                  setFlow({ kind: "idle" });
                  setError(null);
                }}
                aria-label="Close"
              >
                <X className="size-4" />
              </button>
            </div>

            {flow.kind === "pick-mode" ? (
              <div className="mt-5 grid gap-3">
                <Button
                  variant="solid"
                  size="lg"
                  className="h-auto justify-start py-4"
                  disabled={busy}
                  onClick={() => chooseMode("timed")}
                >
                  <Timer className="size-4" />
                  <span className="text-left">
                    <span className="block">Timed</span>
                    <span className="block text-xs font-normal text-ink/70">
                      One minute each. Clock pauses when you move.
                    </span>
                  </span>
                </Button>
                <Button
                  variant="secondary"
                  size="lg"
                  className="h-auto justify-start py-4"
                  disabled={busy}
                  onClick={() => chooseMode("breeze")}
                >
                  <Wind className="size-4" />
                  <span className="text-left">
                    <span className="block">Breeze</span>
                    <span className="block text-xs font-normal text-mist">
                      No clock. Think as long as you like.
                    </span>
                  </span>
                </Button>
              </div>
            ) : null}

            {flow.kind === "ask-name" ? (
              <form className="mt-5 space-y-4" onSubmit={submitChallenge}>
                <Badge>{flow.mode} game</Badge>
                <div className="space-y-2">
                  <Label htmlFor="opp">Club name</Label>
                  <Input
                    id="opp"
                    autoFocus
                    value={target}
                    onChange={(e) => setTarget(e.target.value)}
                    placeholder="Type their club name"
                  />
                </div>
                {error ? <p className="text-sm text-danger">{error}</p> : null}
                <Button type="submit" variant="solid" className="w-full" disabled={busy}>
                  {busy ? "Sending…" : "Send challenge"}
                </Button>
              </form>
            ) : null}

            {flow.kind === "searching" || home.queued ? (
              <div className="mt-5 space-y-3">
                <p className="text-sm text-mist">
                  Looking for a player near {home.profile.score}
                  {flow.kind === "searching" ? ` in ${flow.mode}` : ""}. If no one sits down, you will be
                  seated with {BOT_USERNAME}.
                </p>
                <div className="h-1 overflow-hidden rounded-full bg-ink-soft">
                  <div className="h-full w-1/2 animate-pulse bg-forest" />
                </div>
              </div>
            ) : null}

            {flow.kind === "waiting" ? (
              <p className="mt-5 text-sm text-mist">
                {home.profile.username} wants to battle {flow.username} in chess {flow.mode}. Waiting for
                their yes.
              </p>
            ) : null}

            {error && flow.kind === "pick-mode" ? <p className="mt-3 text-sm text-danger">{error}</p> : null}
          </div>
        </div>
      )}
    </main>
  );
}

function Wordmark() {
  return (
    <div className="flex items-center gap-3">
      <span className="grid size-10 place-items-center overflow-hidden rounded-md bg-forest text-ivory">
        <PieceMark kind="n" className="size-6" />
      </span>
      <div>
        <p className="font-display text-xl font-semibold tracking-wordmark text-ivory">MORES</p>
        <p className="text-xs uppercase tracking-[0.18em] text-mist">Chess club</p>
      </div>
    </div>
  );
}
