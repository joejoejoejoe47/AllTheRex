import { useState, type FormEvent } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Eye, EyeOff } from "lucide-react";
import { GROK_PROVIDERS, authClient, signIn } from "@/lib/auth/client";
import { claimUsername, usernameAvailable } from "@/lib/server/mores";
import { USERNAME_RE, usernameToEmail } from "@/lib/mores-constants";
import { MiniBoard, PieceMark } from "@/components/chess/marks";
import { ThemeToggle } from "@/components/theme";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type Mode = "create" | "enter";

export function AuthScreen() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("create");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    const name = username.trim();
    if (!USERNAME_RE.test(name)) {
      setError("Club names are 3–20 letters, numbers, or underscores.");
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    setPending(true);
    try {
      const email = usernameToEmail(name);
      if (mode === "create") {
        const free = await usernameAvailable({ data: { username: name } });
        if (!free) {
          setError("That club name is already taken.");
          return;
        }
        const { error: signErr } = await authClient.signUp.email({
          email,
          password,
          name,
        });
        if (signErr) {
          setError(signErr.message || "Could not create that account.");
          return;
        }
        await authClient.getSession();
        await claimUsername({ data: { username: name } });
      } else {
        const { error: signErr } = await authClient.signIn.email({ email, password });
        if (signErr) {
          setError(signErr.message || "Club name or password is wrong.");
          return;
        }
      }
      await navigate({ to: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="relative mx-auto flex min-h-dvh w-full max-w-6xl flex-col px-5 py-8 sm:px-8">
      <div className="check-wash pointer-events-none absolute inset-0" />
      <header className="relative z-10 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="grid size-10 place-items-center rounded-md bg-forest text-ivory">
            <PieceMark kind="n" className="size-6" />
          </span>
          <div>
            <p className="font-display text-xl font-semibold tracking-wordmark text-ivory">MORES</p>
            <p className="text-xs uppercase tracking-[0.18em] text-mist">Chess club</p>
          </div>
        </div>
        <ThemeToggle />
      </header>

      <section className="relative z-10 mt-12 grid flex-1 items-center gap-12 lg:mt-0 lg:grid-cols-[1.05fr_0.95fr]">
        <div className="max-w-xl">
          <p className="text-xs uppercase tracking-[0.2em] text-mist">Ivory and ebony. Named seats.</p>
          <h1 className="mt-4 font-display text-4xl font-semibold text-ivory sm:text-5xl">
            Sit down under your own name.
          </h1>
          <p className="mt-5 max-w-md text-base text-mist">
            Create a club name, walk back in with it, and send a challenge across the room. Timed seats
            flag after one minute a turn. Checkmate takes eight rating points.
          </p>
          <MiniBoard className="mt-8 hidden max-w-sm sm:block" />
        </div>

        <div className="rounded-xl border border-line bg-panel p-5 sm:p-7">
          <div className="grid grid-cols-2 rounded-md bg-ink-soft p-1">
            {(
              [
                ["create", "Create account"],
                ["enter", "Sign in"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => {
                  setMode(id);
                  setError(null);
                }}
                className={
                  mode === id
                    ? "h-10 rounded-sm bg-panel-2 text-sm font-medium text-ivory"
                    : "h-10 rounded-sm text-sm font-medium text-mist"
                }
              >
                {label}
              </button>
            ))}
          </div>

          <form className="mt-6 space-y-4" onSubmit={onSubmit}>
            <div className="space-y-2">
              <Label htmlFor="club-name">Club name</Label>
              <Input
                id="club-name"
                autoComplete="username"
                autoFocus
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="e.g. NorthBoard"
                maxLength={20}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="club-pass">Password</Label>
              <div className="relative">
                <Input
                  id="club-pass"
                  type={show ? "text" : "password"}
                  autoComplete={mode === "create" ? "new-password" : "current-password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 8 characters"
                  className="pr-11"
                />
                <button
                  type="button"
                  className="absolute right-2 top-1/2 grid size-8 -translate-y-1/2 place-items-center text-mist hover:text-ivory"
                  onClick={() => setShow((v) => !v)}
                  aria-label={show ? "Hide password" : "Show password"}
                >
                  {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
            </div>
            {error ? <p className="text-sm text-danger">{error}</p> : null}
            <Button type="submit" variant="solid" size="lg" className="w-full" disabled={pending}>
              {pending ? "Entering…" : mode === "create" ? "Create account" : "Enter the club"}
            </Button>
          </form>

          <div className="mt-6 flex items-center gap-3 text-xs uppercase tracking-[0.16em] text-mist">
            <span className="h-px flex-1 bg-line" />
            or
            <span className="h-px flex-1 bg-line" />
          </div>
          <div className="mt-4 grid gap-2">
            {GROK_PROVIDERS.map((p) => (
              <Button
                key={p.providerId}
                type="button"
                variant="secondary"
                className="w-full"
                onClick={() => signIn(p.providerId, { callbackURL: "/" })}
              >
                Continue with {p.label}
              </Button>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

export function SplashSkeleton() {
  return (
    <main className="relative mx-auto flex min-h-dvh w-full max-w-6xl flex-col px-5 py-8 sm:px-8">
      <div className="check-wash pointer-events-none absolute inset-0" />
      <div className="relative flex items-center gap-3">
        <span className="grid size-10 place-items-center rounded-md bg-forest text-ivory">
          <PieceMark kind="n" className="size-6" />
        </span>
        <p className="font-display text-xl font-semibold tracking-wordmark text-ivory">MORES</p>
      </div>
      <h1 className="relative mt-16 font-display text-4xl text-ivory">Setting the pieces</h1>
      <p className="relative mt-4 max-w-md text-sm text-mist">Opening the club. White to move shortly.</p>
    </main>
  );
}
