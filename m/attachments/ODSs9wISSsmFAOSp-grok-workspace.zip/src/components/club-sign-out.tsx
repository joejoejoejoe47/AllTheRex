import { useState, useSyncExternalStore } from "react";
import { authEnabled, signOut } from "@/lib/auth/client";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { Button } from "@/components/ui/button";

const subscribeToNothing = () => () => {};
const noGateOnServer = () => false;

export function ClubSignOut() {
  const [signingOut, setSigningOut] = useState(false);
  const [failed, setFailed] = useState(false);
  const gateSession = useSyncExternalStore(
    subscribeToNothing,
    hasGateSessionMarker,
    noGateOnServer,
  );
  if (!authEnabled || gateSession) return null;

  return (
    <Button
      type="button"
      variant="outline"
      size="sm"
      className="min-w-24"
      disabled={signingOut}
      onClick={() => {
        setSigningOut(true);
        setFailed(false);
        void signOut("/").catch(() => {
          setSigningOut(false);
          setFailed(true);
        });
      }}
    >
      {signingOut ? "Signing out…" : failed ? "Try again" : "Sign out"}
    </Button>
  );
}
