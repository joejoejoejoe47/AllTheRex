import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import type { Square } from "chess.js";
import { Flag, Undo2 } from "lucide-react";
import {
  claimTimeout,
  getGame,
  makeMove,
  resignGame,
  type GameSnapshot,
} from "@/lib/server/mores";
import { SCORE_DELTA, formatClock } from "@/lib/mores-constants";
import { Button } from "@/components/ui/button";
import { PieceMark } from "@/components/chess/marks";
import { ThemeToggle, useTheme } from "@/components/theme";
import { cn } from "@/lib/utils";

const ChessBoard3D = lazy(() =>
  import("@/components/chess/board-3d").then((m) => ({ default: m.ChessBoard3D })),
);

function playTone(freq: number, dur = 0.1, gain = 0.04) {
  try {
    const ctx = new AudioContext();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = "sine";
    o.frequency.value = freq;
    g.gain.setValueAtTime(gain, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
    o.connect(g).connect(ctx.destination);
    o.start();
    o.stop(ctx.currentTime + dur);
  } catch {
    /* audio optional */
  }
}

function ResultOverlay({ game }: { game: GameSnapshot }) {
  const won =
    (game.status === "white_win" && game.you === "w") ||
    (game.status === "black_win" && game.you === "b");
  const draw = game.status === "draw";
  return (
    <div className="absolute inset-0 z-20 grid place-items-center bg-ink/75 px-5">
      <div className="w-full max-w-md rounded-xl border border-line bg-panel p-8 text-center">
        <p className="text-xs uppercase tracking-[0.2em] text-mist">
          {draw ? "Drawn game" : won ? "Checkmate is yours" : "Checkmate against you"}
        </p>
        <h2 className="mt-3 font-display text-5xl text-ivory">
          {draw ? "Draw" : won ? "Victory" : "Defeat"}
        </h2>
        <p className="mt-4 text-sm text-mist">
          {draw
            ? "Rating unchanged."
            : won
              ? `You take ${SCORE_DELTA} rating points.`
              : `You drop ${SCORE_DELTA} rating points.`}
        </p>
        <p className="mt-1 font-mono text-lg tabular-nums text-ivory">Rating {game.myScore}</p>
        <Button asChild variant="solid" className="mt-6">
          <Link to="/">Return to the clubhouse</Link>
        </Button>
      </div>
    </div>
  );
}

export function GameView({ gameId }: { gameId: string }) {
  const theme = useTheme();
  const [game, setGame] = useState<GameSnapshot | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [clocks, setClocks] = useState({ w: 0, b: 0 });
  const lastSan = useRef<string | null>(null);
  const lastTurn = useRef<string | null>(null);

  useEffect(() => {
    let live = true;
    const tick = async () => {
      try {
        const snap = await getGame({ data: { gameId } });
        if (!live) return;
        if (!snap) {
          setError("This board is not yours, or it no longer exists.");
          return;
        }
        setGame(snap);
        setError(null);
        setClocks({ w: snap.whiteClockMs ?? 60_000, b: snap.blackClockMs ?? 60_000 });
        if (snap.lastMove && snap.lastMove.san !== lastSan.current) {
          if (lastSan.current) playTone(snap.turn === snap.you ? 380 : 520, 0.09, 0.035);
          lastSan.current = snap.lastMove.san;
        }
        lastTurn.current = snap.turn;
      } catch (e) {
        if (live) setError(e instanceof Error ? e.message : "Lost the board connection.");
      }
    };
    void tick();
    const id = window.setInterval(() => void tick(), 700);
    return () => {
      live = false;
      window.clearInterval(id);
    };
  }, [gameId]);

  useEffect(() => {
    if (!game || game.mode !== "timed" || game.status !== "active") return;
    const id = window.setInterval(() => {
      setClocks((prev) => {
        const key = game.turn;
        const next = Math.max(0, prev[key] - 250);
        if (next === prev[key]) return prev;
        return { ...prev, [key]: next };
      });
    }, 250);
    return () => window.clearInterval(id);
  }, [game?.mode, game?.status, game?.turn, game?.id]);

  useEffect(() => {
    if (!game || game.mode !== "timed" || game.status !== "active") return;
    const active = game.turn === "w" ? clocks.w : clocks.b;
    if (active > 0) return;
    void claimTimeout({ data: { gameId } }).then((snap) => {
      if (snap) {
        setGame(snap);
        setClocks({ w: snap.whiteClockMs ?? 60_000, b: snap.blackClockMs ?? 60_000 });
      }
    });
  }, [clocks, game, gameId]);

  async function onMove(from: Square, to: Square) {
    const res = await makeMove({ data: { gameId, from, to } });
    if (res.ok && res.game) {
      setGame(res.game);
      setClocks({ w: res.game.whiteClockMs ?? 60_000, b: res.game.blackClockMs ?? 60_000 });
    }
  }

  if (error && !game) {
    return (
      <main className="grid min-h-dvh place-items-center px-5">
        <div className="max-w-sm text-center">
          <p className="text-sm text-danger">{error}</p>
          <Button asChild variant="solid" className="mt-4">
            <Link to="/">Back to the clubhouse</Link>
          </Button>
        </div>
      </main>
    );
  }

  if (!game) {
    return (
      <main className="grid min-h-dvh place-items-center">
        <p className="text-sm text-mist">Setting the board…</p>
      </main>
    );
  }

  const myTurn = game.status === "active" && game.turn === game.you;
  const myName = game.you === "w" ? game.white.username : game.black.username;
  const opp = game.you === "w" ? game.black : game.white;
  const myClock = game.you === "w" ? clocks.w : clocks.b;
  const oppClock = game.you === "w" ? clocks.b : clocks.w;
  const over = game.status !== "active";
  const turnLabel = game.turn === "w" ? "White to move" : "Black to move";

  return (
    <main className="relative flex h-dvh flex-col overflow-hidden bg-ink">
      <header className="flex items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <Link to="/" className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-mist hover:text-ivory">
          <PieceMark kind="n" className="size-4" />
          Mores
        </Link>
        <p className="text-center text-xs uppercase tracking-[0.16em] text-mist">
          {game.mode === "timed" ? "Timed · 1 min each" : "Breeze · no clock"}
          <span className="mt-0.5 block font-sans tracking-normal text-ivory">
            {over ? "Game over" : myTurn ? "Your move" : turnLabel}
          </span>
        </p>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          {game.status === "active" ? (
            <Button
              size="sm"
              variant="ghost"
              onClick={async () => {
                const snap = await resignGame({ data: { gameId } });
                if (snap) setGame(snap);
              }}
            >
              <Flag className="size-3.5" />
              Resign
            </Button>
          ) : (
            <Button asChild size="sm" variant="ghost">
              <Link to="/">
                <Undo2 className="size-3.5" />
                Clubhouse
              </Link>
            </Button>
          )}
        </div>
      </header>

      <PlayerStrip
        name={opp.username}
        score={opp.score}
        color={game.you === "w" ? "Black" : "White"}
        side={game.you === "w" ? "b" : "w"}
        clock={game.mode === "timed" ? oppClock : null}
        active={!myTurn && !over}
      />

      <div className="relative min-h-0 flex-1">
        <div className="absolute inset-0">
          <Suspense
            fallback={
              <div className="grid h-full place-items-center text-sm text-mist">Setting the board…</div>
            }
          >
            <ChessBoard3D
              fen={game.fen}
              you={game.you}
              lastMove={game.lastMove}
              myTurn={myTurn}
              onMove={onMove}
              disabled={over}
              appearance={theme}
            />
          </Suspense>
        </div>
        {over ? <ResultOverlay game={game} /> : null}
      </div>

      <PlayerStrip
        name={myName}
        score={game.you === "w" ? game.white.score : game.black.score}
        color={game.you === "w" ? "White" : "Black"}
        side={game.you}
        clock={game.mode === "timed" ? myClock : null}
        active={myTurn && !over}
        moves={game.moves.map((m) => m.san).slice(-8)}
      />
    </main>
  );
}

function PlayerStrip({
  name,
  score,
  color,
  side,
  clock,
  active,
  moves,
}: {
  name: string;
  score: number;
  color: string;
  side: "w" | "b";
  clock: number | null;
  active: boolean;
  moves?: string[];
}) {
  const low = clock !== null && clock <= 10_000 && active;
  return (
    <div className="flex items-center justify-between gap-3 px-4 py-3 sm:px-6">
      <div className="flex min-w-0 items-center gap-3">
        <span
          className={cn(
            "grid size-9 place-items-center rounded-md border",
            side === "w" ? "border-line bg-cream text-piece-b" : "border-line bg-ink-soft text-piece-w",
          )}
        >
          <PieceMark kind="k" tone={side} className="size-6" />
        </span>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium text-ivory">
            {name}{" "}
            <span className="font-sans text-xs font-normal text-mist">
              {color} · {score}
            </span>
          </p>
          {moves && moves.length > 0 ? (
            <p className="mt-0.5 max-w-[55vw] truncate font-mono text-xs text-mist">{moves.join("  ")}</p>
          ) : null}
        </div>
      </div>
      {clock !== null ? (
        <p
          className={cn(
            "rounded-md border px-3 py-1.5 font-mono text-xl tabular-nums",
            active
              ? low
                ? "border-danger text-danger"
                : "border-line-strong bg-panel text-ivory"
              : "border-line text-mist",
          )}
        >
          {formatClock(clock)}
        </p>
      ) : null}
    </div>
  );
}
