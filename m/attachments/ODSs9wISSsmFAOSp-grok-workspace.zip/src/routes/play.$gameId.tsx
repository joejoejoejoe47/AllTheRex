import { createFileRoute, Navigate } from "@tanstack/react-router";
import { GameView } from "@/components/game-view";
import { SplashSkeleton } from "@/components/auth-screen";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RedirectToSignIn } from "@/lib/auth/gates";

export const Route = createFileRoute("/play/$gameId")({
  ssr: false,
  component: PlayPage,
});

function PlayPage() {
  const { gameId } = Route.useParams();
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <SplashSkeleton />;
  if (!user) return <RedirectToSignIn />;
  if (!gameId) return <Navigate to="/" />;
  return <GameView gameId={gameId} />;
}
