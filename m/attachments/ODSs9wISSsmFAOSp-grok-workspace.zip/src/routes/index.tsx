import { createFileRoute } from "@tanstack/react-router";
import { AuthScreen, SplashSkeleton } from "@/components/auth-screen";
import { ClubHome } from "@/components/club-home";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <SplashSkeleton />;
  if (!user) return <AuthScreen />;
  return <ClubHome />;
}
