import { createServerFn } from "@tanstack/react-start";
import { Chess } from "chess.js";
import type { Square } from "chess.js";
import { getSql, type Sql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  BOT_USER_ID,
  SCORE_DELTA,
  START_SCORE,
  TURN_MS,
  USERNAME_RE,
  type GameMode,
  type GameStatus,
  type Side,
} from "@/lib/mores-constants";

type ProfileRow = {
  user_id: string;
  username: string;
  username_lc: string;
  score: number;
};

type GameRow = {
  id: string;
  white_user_id: string;
  black_user_id: string;
  mode: GameMode;
  fen: string;
  status: GameStatus;
  turn: Side;
  last_move_from: string | null;
  last_move_to: string | null;
  last_move_san: string | null;
  turn_started_at: string | number | Date;
  white_clock_ms: number | string | null;
  black_clock_ms: number | string | null;
  winner_user_id: string | null;
  scored: boolean | string | number;
};

export type PlayerInfo = { userId: string; username: string; score: number };

export type GameSnapshot = {
  id: string;
  fen: string;
  mode: GameMode;
  status: GameStatus;
  turn: Side;
  you: Side;
  white: PlayerInfo;
  black: PlayerInfo;
  lastMove: { from: string; to: string; san: string } | null;
  remainingMs: number;
  whiteClockMs: number;
  blackClockMs: number;
  serverNow: number;
  moves: { san: string; from: string; to: string }[];
  winnerUserId: string | null;
  myScore: number;
  opponentName: string;
};

export type ChallengeCard = {
  id: string;
  fromUsername: string;
  toUsername: string;
  mode: GameMode;
  status: string;
  createdAt: string;
};

export type HomeState = {
  profile: { username: string; score: number } | null;
  inbox: ChallengeCard[];
  outgoing: ChallengeCard[];
  activeGameId: string | null;
  queued: boolean;
  queueMode: GameMode | null;
  online: { username: string; score: number }[];
  leaders: { username: string; score: number }[];
};

const PIECE_VAL: Record<string, number> = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 0,
};

function asTime(v: unknown): number {
  if (typeof v === "number" && Number.isFinite(v)) {
    return v < 1e12 ? v * 1000 : v;
  }
  if (v instanceof Date) return v.getTime();
  if (typeof v === "string") {
    const n = Date.parse(v);
    return Number.isFinite(n) ? n : Date.now();
  }
  return Date.now();
}

function toInt(v: unknown, fallback: number) {
  const n = typeof v === "number" ? v : typeof v === "string" ? Number(v) : NaN;
  return Number.isFinite(n) ? n : fallback;
}

function liveClocks(game: GameRow) {
  const storedW = toInt(game.white_clock_ms, TURN_MS);
  const storedB = toInt(game.black_clock_ms, TURN_MS);
  if (game.status !== "active" || game.mode !== "timed") {
    return { w: storedW, b: storedB };
  }
  const elapsed = Math.max(0, Date.now() - asTime(game.turn_started_at));
  if (game.turn === "w") return { w: Math.max(0, storedW - elapsed), b: storedB };
  return { w: storedW, b: Math.max(0, storedB - elapsed) };
}

function asBool(v: unknown): boolean {
  return v === true || v === "t" || v === "true" || v === 1 || v === "1";
}

function parseMode(v: unknown): GameMode {
  return v === "breeze" ? "breeze" : "timed";
}

function newId() {
  return crypto.randomUUID();
}

function cleanUsername(raw: string) {
  const username = raw.trim();
  if (!USERNAME_RE.test(username)) {
    throw new Error("Club names are 3–20 letters, numbers, or underscores.");
  }
  return username;
}

async function profileById(sql: Sql, userId: string) {
  const rows = await sql<ProfileRow>`
    select user_id, username, username_lc, score from profiles where user_id = ${userId} limit 1
  `;
  return rows[0] ?? null;
}

async function touchProfile(sql: Sql, userId: string) {
  await sql`update profiles set last_seen = now() where user_id = ${userId}`;
}

async function insertGame(sql: Sql, a: string, b: string, mode: GameMode) {
  const id = newId();
  const aWhite = Math.random() < 0.5;
  const white = aWhite ? a : b;
  const black = aWhite ? b : a;
  const chess = new Chess();
  await sql`
    insert into games (
      id, white_user_id, black_user_id, mode, fen, status, turn, turn_started_at,
      white_clock_ms, black_clock_ms
    ) values (
      ${id}, ${white}, ${black}, ${mode}, ${chess.fen()}, 'active', 'w', ${new Date().toISOString()},
      ${TURN_MS}, ${TURN_MS}
    )
  `;
  return id;
}

async function loadGame(sql: Sql, gameId: string) {
  const rows = await sql<GameRow>`select * from games where id = ${gameId} limit 1`;
  return rows[0] ?? null;
}

async function applyScore(sql: Sql, winnerId: string, loserId: string) {
  if (winnerId !== BOT_USER_ID) {
    await sql`update profiles set score = score + ${SCORE_DELTA} where user_id = ${winnerId}`;
  }
  if (loserId !== BOT_USER_ID) {
    await sql`update profiles set score = greatest(0, score - ${SCORE_DELTA}) where user_id = ${loserId}`;
  }
}

async function finishGame(
  sql: Sql,
  game: GameRow,
  status: GameStatus,
  winnerUserId: string | null,
) {
  if (game.status !== "active") return;
  const scored = status !== "draw";
  await sql`
    update games
    set status = ${status},
        winner_user_id = ${winnerUserId},
        scored = ${scored}
    where id = ${game.id} and status = 'active'
  `;
  if (scored && winnerUserId) {
    const loser = winnerUserId === game.white_user_id ? game.black_user_id : game.white_user_id;
    await applyScore(sql, winnerUserId, loser);
  }
  game.status = status;
  game.winner_user_id = winnerUserId;
  game.scored = scored;
}

function evaluate(chess: Chess, bot: Side): number {
  if (chess.isCheckmate()) return chess.turn() === bot ? -100000 : 100000;
  if (chess.isDraw() || chess.isStalemate()) return 0;
  let s = 0;
  for (const row of chess.board()) {
    for (const p of row) {
      if (!p) continue;
      const v = PIECE_VAL[p.type] ?? 0;
      s += p.color === bot ? v : -v;
    }
  }
  const mobility = chess.moves().length;
  s += chess.turn() === bot ? mobility * 2 : -mobility * 2;
  if (chess.isCheck()) s += chess.turn() === bot ? -40 : 40;
  return s;
}

function pickBotMove(fen: string, botSide: Side) {
  const chess = new Chess(fen);
  if (chess.turn() !== botSide) return null;
  const bot = botSide;
  const moves = chess.moves({ verbose: true });
  if (!moves.length) return null;
  let best = -Infinity;
  const top: typeof moves = [];
  for (const m of moves) {
    chess.move(m);
    const score = evaluate(chess, bot);
    chess.undo();
    if (score > best + 8) {
      best = score;
      top.length = 0;
      top.push(m);
    } else if (score >= best - 8) {
      if (score > best) best = score;
      top.push(m);
    }
  }
  const pick = top[Math.floor(Math.random() * top.length)] ?? moves[0];
  return { from: pick.from, to: pick.to, promotion: pick.promotion as string | undefined };
}

async function recordAndApplyMove(
  sql: Sql,
  game: GameRow,
  from: string,
  to: string,
  promotion?: string,
) {
  const chess = new Chess(game.fen);
  const needsPromo =
    chess.get(from as Square)?.type === "p" && (to.endsWith("8") || to.endsWith("1"));
  const moved = chess.move({
    from: from as Square,
    to: to as Square,
    promotion: (needsPromo ? promotion ?? "q" : undefined) as "q" | "r" | "b" | "n" | undefined,
  });
  if (!moved) return { ok: false as const, error: "That move is not legal." };

  const plyRows = await sql<{ c: number }>`select count(*)::int as c from game_moves where game_id = ${game.id}`;
  const ply = (plyRows[0]?.c ?? 0) + 1;
  await sql`
    insert into game_moves (game_id, ply, san, from_sq, to_sq)
    values (${game.id}, ${ply}, ${moved.san}, ${moved.from}, ${moved.to})
  `;

  let status: GameStatus = "active";
  let winner: string | null = null;
  if (chess.isCheckmate()) {
    status = moved.color === "w" ? "white_win" : "black_win";
    winner = moved.color === "w" ? game.white_user_id : game.black_user_id;
  } else if (chess.isDraw() || chess.isStalemate()) {
    status = "draw";
  }

  const now = new Date().toISOString();
  const clocks = liveClocks(game);
  await sql`
    update games set
      fen = ${chess.fen()},
      turn = ${chess.turn()},
      last_move_from = ${moved.from},
      last_move_to = ${moved.to},
      last_move_san = ${moved.san},
      turn_started_at = ${now},
      white_clock_ms = ${clocks.w},
      black_clock_ms = ${clocks.b},
      status = ${status},
      winner_user_id = ${winner},
      scored = ${status !== "active" && status !== "draw"}
    where id = ${game.id}
  `;

  game.fen = chess.fen();
  game.turn = chess.turn();
  game.last_move_from = moved.from;
  game.last_move_to = moved.to;
  game.last_move_san = moved.san;
  game.turn_started_at = now;
  game.white_clock_ms = clocks.w;
  game.black_clock_ms = clocks.b;
  game.status = status;
  game.winner_user_id = winner;

  if (status === "white_win" || status === "black_win") {
    const loser = winner === game.white_user_id ? game.black_user_id : game.white_user_id;
    if (winner) await applyScore(sql, winner, loser);
    game.scored = true;
  }
  return { ok: true as const };
}

async function maybeTimeout(sql: Sql, game: GameRow) {
  if (game.status !== "active" || game.mode !== "timed") return;
  const clocks = liveClocks(game);
  const remaining = game.turn === "w" ? clocks.w : clocks.b;
  if (remaining > 0) return;
  const winner = game.turn === "w" ? game.black_user_id : game.white_user_id;
  await finishGame(sql, game, game.turn === "w" ? "black_win" : "white_win", winner);
}

async function maybeBotMove(sql: Sql, game: GameRow) {
  if (game.status !== "active") return;
  const botSide: Side | null =
    game.white_user_id === BOT_USER_ID ? "w" : game.black_user_id === BOT_USER_ID ? "b" : null;
  if (!botSide || game.turn !== botSide) return;
  const position = new Chess(game.fen);
  if (position.turn() !== botSide) return;
  const thinkMs = 1100;
  if (Date.now() - asTime(game.turn_started_at) < thinkMs) return;
  const pick = pickBotMove(game.fen, botSide);
  if (!pick) {
    if (position.isCheckmate()) {
      const winner = botSide === "w" ? game.black_user_id : game.white_user_id;
      await finishGame(sql, game, botSide === "w" ? "black_win" : "white_win", winner);
    } else {
      await finishGame(sql, game, "draw", null);
    }
    return;
  }
  const piece = position.get(pick.from as Square);
  if (!piece || piece.color !== botSide) return;
  await recordAndApplyMove(sql, game, pick.from, pick.to, pick.promotion);
}

async function snapshotFor(sql: Sql, game: GameRow, userId: string): Promise<GameSnapshot | null> {
  if (game.white_user_id !== userId && game.black_user_id !== userId) return null;
  await maybeTimeout(sql, game);
  await maybeBotMove(sql, game);
  const fresh = (await loadGame(sql, game.id)) ?? game;
  const [white, black] = await Promise.all([
    profileById(sql, fresh.white_user_id),
    profileById(sql, fresh.black_user_id),
  ]);
  const moves = await sql<{ san: string; from_sq: string; to_sq: string }>`
    select san, from_sq, to_sq from game_moves where game_id = ${fresh.id} order by ply asc
  `;
  const you: Side = fresh.white_user_id === userId ? "w" : "b";
  const clocks = liveClocks(fresh);
  const remainingMs = fresh.turn === "w" ? clocks.w : clocks.b;
  const me = you === "w" ? white : black;
  const opp = you === "w" ? black : white;
  return {
    id: fresh.id,
    fen: fresh.fen,
    mode: parseMode(fresh.mode),
    status: fresh.status,
    turn: fresh.turn,
    you,
    white: {
      userId: fresh.white_user_id,
      username: white?.username ?? "White",
      score: white?.score ?? START_SCORE,
    },
    black: {
      userId: fresh.black_user_id,
      username: black?.username ?? "Black",
      score: black?.score ?? START_SCORE,
    },
    lastMove:
      fresh.last_move_from && fresh.last_move_to && fresh.last_move_san
        ? { from: fresh.last_move_from, to: fresh.last_move_to, san: fresh.last_move_san }
        : null,
    remainingMs,
    whiteClockMs: clocks.w,
    blackClockMs: clocks.b,
    serverNow: Date.now(),
    moves: moves.map((m) => ({ san: m.san, from: m.from_sq, to: m.to_sq })),
    winnerUserId: fresh.winner_user_id,
    myScore: me?.score ?? START_SCORE,
    opponentName: opp?.username ?? "Opponent",
  };
}

async function tryMatch(sql: Sql, userId: string, score: number, mode: GameMode, joinedAt: unknown) {
  const wait = Date.now() - asTime(joinedAt);
  const window = wait > 7000 ? 4000 : wait > 3500 ? 180 : 70;
  const rows = await sql<{ user_id: string; score: number }>`
    select user_id, score from match_queue
    where user_id <> ${userId} and mode = ${mode}
    order by joined_at asc
  `;
  const opp = rows.find((r) => Math.abs(Number(r.score) - score) <= window);
  if (opp) {
    const taken = await sql<{ user_id: string }>`
      delete from match_queue where user_id = ${opp.user_id} returning user_id
    `;
    if (taken.length) {
      await sql`delete from match_queue where user_id = ${userId}`;
      return insertGame(sql, userId, opp.user_id, mode);
    }
  }
  if (wait > 8000) {
    await sql`delete from match_queue where user_id = ${userId}`;
    return insertGame(sql, userId, BOT_USER_ID, mode);
  }
  return null;
}

export const usernameAvailable = createServerFn({ method: "POST" })
  .validator((input: { username: string }) => ({ username: cleanUsername(input.username) }))
  .handler(async ({ data }) => {
    const sql = await getSql();
    const rows = await sql`
      select 1 from profiles where username_lc = ${data.username.toLowerCase()} limit 1
    `;
    return rows.length === 0;
  });

export const claimUsername = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { username: string }) => ({ username: cleanUsername(input.username) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const existing = await profileById(sql, context.userId);
    if (existing) return { username: existing.username, score: existing.score };
    try {
      await sql`
        insert into profiles (user_id, username, username_lc, score)
        values (${context.userId}, ${data.username}, ${data.username.toLowerCase()}, ${START_SCORE})
      `;
    } catch {
      throw new Error("That club name is already taken.");
    }
    return { username: data.username, score: START_SCORE };
  });

export const getHomeState = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<HomeState> => {
    const sql = await getSql();
    const profile = await profileById(sql, context.userId);
    if (!profile) {
      return {
        profile: null,
        inbox: [],
        outgoing: [],
        activeGameId: null,
        queued: false,
        queueMode: null,
        online: [],
        leaders: [],
      };
    }
    await touchProfile(sql, context.userId);

    const active = await sql<{ id: string }>`
      select id from games
      where status = 'active' and (white_user_id = ${context.userId} or black_user_id = ${context.userId})
      order by created_at desc
      limit 1
    `;

    const q = await sql<{ mode: GameMode; joined_at: string | Date }>`
      select mode, joined_at from match_queue where user_id = ${context.userId} limit 1
    `;
    let queued = q.length > 0;
    let queueMode: GameMode | null = q[0] ? parseMode(q[0].mode) : null;
    let matched: string | null = null;
    if (q[0]) {
      matched = await tryMatch(sql, context.userId, Number(profile.score), parseMode(q[0].mode), q[0].joined_at);
      if (matched) {
        queued = false;
        queueMode = null;
      }
    }

    const inboxRows = await sql<{
      id: string;
      mode: string;
      status: string;
      created_at: string | Date;
      username: string;
    }>`
      select c.id, c.mode, c.status, c.created_at, p.username
      from challenges c
      join profiles p on p.user_id = c.from_user_id
      where c.to_user_id = ${context.userId} and c.status = 'pending'
      order by c.created_at desc
    `;
    const outRows = await sql<{
      id: string;
      mode: string;
      status: string;
      created_at: string | Date;
      username: string;
    }>`
      select c.id, c.mode, c.status, c.created_at, p.username
      from challenges c
      join profiles p on p.user_id = c.to_user_id
      where c.from_user_id = ${context.userId} and c.status in ('pending', 'declined')
      order by c.created_at desc
      limit 8
    `;
    const online = await sql<{ username: string; score: number }>`
      select username, score from profiles
      where user_id <> ${context.userId}
        and user_id <> ${BOT_USER_ID}
        and last_seen > now() - interval '20 seconds'
      order by score desc
      limit 12
    `;
    const leaders = await sql<{ username: string; score: number }>`
      select username, score from profiles
      order by score desc, created_at asc
      limit 8
    `;

    return {
      profile: { username: profile.username, score: Number(profile.score) },
      inbox: inboxRows.map((r) => ({
        id: r.id,
        fromUsername: r.username,
        toUsername: profile.username,
        mode: parseMode(r.mode),
        status: r.status,
        createdAt: String(r.created_at),
      })),
      outgoing: outRows.map((r) => ({
        id: r.id,
        fromUsername: profile.username,
        toUsername: r.username,
        mode: parseMode(r.mode),
        status: r.status,
        createdAt: String(r.created_at),
      })),
      activeGameId: matched ?? active[0]?.id ?? null,
      queued,
      queueMode,
      online: online.map((r) => ({ username: r.username, score: Number(r.score) })),
      leaders: leaders.map((r) => ({ username: r.username, score: Number(r.score) })),
    };
  });

export const joinQueue = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { mode: GameMode }) => ({ mode: parseMode(input.mode) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const profile = await profileById(sql, context.userId);
    if (!profile) throw new Error("Choose a club name first.");
    const active = await sql<{ id: string }>`
      select id from games
      where status = 'active' and (white_user_id = ${context.userId} or black_user_id = ${context.userId})
      limit 1
    `;
    if (active[0]) return { gameId: active[0].id };
    await sql`
      insert into match_queue (user_id, score, mode, joined_at)
      values (${context.userId}, ${profile.score}, ${data.mode}, ${new Date().toISOString()})
      on conflict (user_id) do update set score = excluded.score, mode = excluded.mode, joined_at = excluded.joined_at
    `;
    const gameId = await tryMatch(
      sql,
      context.userId,
      Number(profile.score),
      data.mode,
      new Date().toISOString(),
    );
    return { gameId };
  });

export const leaveQueue = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await sql`delete from match_queue where user_id = ${context.userId}`;
    return { ok: true };
  });

export const sendChallenge = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { username: string; mode: GameMode }) => ({
    username: cleanUsername(input.username),
    mode: parseMode(input.mode),
  }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = await profileById(sql, context.userId);
    if (!me) throw new Error("Choose a club name first.");
    const active = await sql<{ id: string }>`
      select id from games
      where status = 'active' and (white_user_id = ${context.userId} or black_user_id = ${context.userId})
      limit 1
    `;
    if (active[0]) return { ok: true as const, gameId: active[0].id };

    const target = await sql<ProfileRow>`
      select user_id, username, username_lc, score from profiles
      where username_lc = ${data.username.toLowerCase()}
      limit 1
    `;
    const to = target[0];
    if (!to) return { ok: false as const, error: "No player with that club name." };
    if (to.user_id === context.userId) {
      return { ok: false as const, error: "You cannot challenge yourself." };
    }
    if (to.user_id === BOT_USER_ID) {
      const gameId = await insertGame(sql, context.userId, BOT_USER_ID, data.mode);
      return { ok: true as const, gameId };
    }
    const pending = await sql`
      select 1 from challenges
      where from_user_id = ${context.userId} and to_user_id = ${to.user_id} and status = 'pending'
      limit 1
    `;
    if (pending.length) return { ok: false as const, error: "You already sent them a challenge." };
    const id = newId();
    await sql`
      insert into challenges (id, from_user_id, to_user_id, mode, status)
      values (${id}, ${context.userId}, ${to.user_id}, ${data.mode}, 'pending')
    `;
    return { ok: true as const, challengeId: id };
  });

export const respondChallenge = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; accept: boolean }) => ({
    id: String(input.id),
    accept: Boolean(input.accept),
  }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      from_user_id: string;
      to_user_id: string;
      mode: string;
      status: string;
    }>`
      select id, from_user_id, to_user_id, mode, status from challenges where id = ${data.id} limit 1
    `;
    const ch = rows[0];
    if (!ch || ch.to_user_id !== context.userId) {
      return { ok: false as const, error: "Challenge not found." };
    }
    if (ch.status !== "pending") return { ok: false as const, error: "That challenge is no longer open." };
    if (!data.accept) {
      await sql`update challenges set status = 'declined' where id = ${ch.id}`;
      return { ok: true as const };
    }
    const gameId = await insertGame(sql, ch.from_user_id, ch.to_user_id, parseMode(ch.mode));
    await sql`update challenges set status = 'accepted', game_id = ${gameId} where id = ${ch.id}`;
    return { ok: true as const, gameId };
  });

export const cancelChallenge = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string }) => ({ id: String(input.id) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      update challenges set status = 'cancelled'
      where id = ${data.id} and from_user_id = ${context.userId} and status = 'pending'
    `;
    return { ok: true };
  });

export const getGame = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { gameId: string }) => ({ gameId: String(input.gameId) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const game = await loadGame(sql, data.gameId);
    if (!game) return null;
    return snapshotFor(sql, game, context.userId);
  });

export const makeMove = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { gameId: string; from: string; to: string; promotion?: string }) => ({
    gameId: String(input.gameId),
    from: String(input.from),
    to: String(input.to),
    promotion: input.promotion,
  }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const game = await loadGame(sql, data.gameId);
    if (!game) return { ok: false as const, error: "Game not found." };
    if (game.status !== "active") return { ok: false as const, error: "This game is over." };
    await maybeTimeout(sql, game);
    if (game.status !== "active") {
      const snap = await snapshotFor(sql, game, context.userId);
      return { ok: false as const, error: "Time expired.", game: snap };
    }
    const side: Side = game.white_user_id === context.userId ? "w" : game.black_user_id === context.userId ? "b" : "w";
    if (game.white_user_id !== context.userId && game.black_user_id !== context.userId) {
      return { ok: false as const, error: "You are not seated at this board." };
    }
    if (game.turn !== side) return { ok: false as const, error: "Wait for your turn." };
    const piece = new Chess(game.fen).get(data.from as Square);
    if (!piece || piece.color !== side) {
      return { ok: false as const, error: "That is not your piece." };
    }
    const applied = await recordAndApplyMove(sql, game, data.from, data.to, data.promotion);
    if (!applied.ok) return applied;
    const snap = await snapshotFor(sql, game, context.userId);
    return { ok: true as const, game: snap };
  });

export const claimTimeout = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { gameId: string }) => ({ gameId: String(input.gameId) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const game = await loadGame(sql, data.gameId);
    if (!game) return null;
    await maybeTimeout(sql, game);
    return snapshotFor(sql, game, context.userId);
  });

export const resignGame = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { gameId: string }) => ({ gameId: String(input.gameId) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const game = await loadGame(sql, data.gameId);
    if (!game) return null;
    if (game.white_user_id !== context.userId && game.black_user_id !== context.userId) return null;
    if (game.status === "active") {
      const winner = game.white_user_id === context.userId ? game.black_user_id : game.white_user_id;
      await finishGame(
        sql,
        game,
        winner === game.white_user_id ? "white_win" : "black_win",
        winner,
      );
    }
    return snapshotFor(sql, game, context.userId);
  });

export const startBotGame = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { mode: GameMode }) => ({ mode: parseMode(input.mode) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = await profileById(sql, context.userId);
    if (!me) throw new Error("Choose a club name first.");
    const active = await sql<{ id: string }>`
      select id from games
      where status = 'active' and (white_user_id = ${context.userId} or black_user_id = ${context.userId})
      limit 1
    `;
    if (active[0]) return { gameId: active[0].id };
    const gameId = await insertGame(sql, context.userId, BOT_USER_ID, data.mode);
    return { gameId };
  });
